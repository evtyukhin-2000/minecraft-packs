#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
#if defined(IS_GUI)
vec4 hudTint = Color;
bool hudDone = false;
int hudR = int(Color.r * 255.0 + 0.5);
int hudG = int(Color.g * 255.0 + 0.5);
int hudB = int(Color.b * 255.0 + 0.5);
if (hudR == 56) {
    gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
    hudTint = vec4(0.0);
    hudDone = true;
} else if (hudR == 225 && (hudB == 5 || hudB == 6 || hudB == 24 || hudB >= 100)) {
    float guiW = 2.0 / max(abs(ProjMat[0][0]), 0.0001);
    float guiH = 2.0 / max(abs(ProjMat[1][1]), 0.0001);
    float widgetW = 196.0;
    float widgetH = 48.0;
    float margin = 8.0;
    float hudScale = 1.0;
    if (widgetW + margin * 2.0 > guiW * 0.5) {
        hudScale = (guiW * 0.5 - margin * 2.0) / widgetW;
    }
    float sidebarBottom = guiH * 0.5 + 58.0;
    float hotbarTop = guiH - 24.0;
    float room = hotbarTop - sidebarBottom - 4.0;
    if (widgetH * hudScale > room && room > 24.0) {
        hudScale = min(hudScale, room / widgetH);
    }
    hudScale = max(hudScale, 0.45);
    float left = guiW - margin - widgetW * hudScale;
    float cornerTop = guiH - margin - widgetH * hudScale;
    float top = cornerTop;
    if (top < sidebarBottom) {
        top = hotbarTop - widgetH * hudScale;
    }
    float hotbarRight = guiW * 0.5 + 96.0;
    if (left < hotbarRight && top + widgetH * hudScale > hotbarTop) {
        top = hotbarTop - widgetH * hudScale;
    }
    float gw = 6.0;
    float gh = 8.0;
    float yOff = 28.0;
    if (hudB == 5) {
        yOff = 9.0;
    } else if (hudB == 24) {
        gw = 24.0;
        gh = 24.0;
        yOff = 12.0;
    } else if (hudB >= 100) {
        gw = widgetW;
        gh = widgetH;
        yOff = 0.0;
    }
    int corner = gl_VertexID % 4;
    float lx = (corner == 2 || corner == 3) ? gw : 0.0;
    float ly = (corner == 1 || corner == 2) ? gh : 0.0;
    gl_Position = ProjMat * vec4(left + (float(hudG) + lx) * hudScale, top + (yOff + ly) * hudScale, Position.z, 1.0);
    hudTint = hudB >= 20 ? vec4(1.0) : vec4(1.0, 0.82, 0.28, 1.0);
    hudDone = true;
}
if (!hudDone) {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
}

    vertexColor = hudTint;
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#if !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
#endif
    texCoord0 = UV0;
}
