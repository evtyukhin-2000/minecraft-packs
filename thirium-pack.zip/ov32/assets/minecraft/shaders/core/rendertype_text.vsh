#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
vec4 hudTint = Color;
bool hudDone = false;
int hudR = int(Color.r * 255.0 + 0.5);
int hudG = int(Color.g * 255.0 + 0.5);
int hudB = int(Color.b * 255.0 + 0.5);
if (hudR == 56) {
    gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
    hudTint = vec4(0.0);
    hudDone = true;
} else if (hudR == 225 && (hudB == 5 || hudB == 6 || hudB == 24 || hudB >= 100)) {
    float guiW = 2.0 / max(abs(ProjMat[0][0]), 0.0001);
    float guiH = 2.0 / max(abs(ProjMat[1][1]), 0.0001);
    float widgetW = 196.0;
    float widgetH = 48.0;
    float margin = 8.0;
    float hudScale = 1.0;
    if (widgetW + margin * 2.0 > guiW * 0.5) {
        hudScale = (guiW * 0.5 - margin * 2.0) / widgetW;
    }
    float sidebarBottom = guiH * 0.5 + 58.0;
    float hotbarTop = guiH - 24.0;
    float room = hotbarTop - sidebarBottom - 4.0;
    if (widgetH * hudScale > room && room > 24.0) {
        hudScale = min(hudScale, room / widgetH);
    }
    hudScale = max(hudScale, 0.45);
    float left = guiW - margin - widgetW * hudScale;
    float cornerTop = guiH - margin - widgetH * hudScale;
    float top = cornerTop;
    if (top < sidebarBottom) {
        top = hotbarTop - widgetH * hudScale;
    }
    float hotbarRight = guiW * 0.5 + 96.0;
    if (left < hotbarRight && top + widgetH * hudScale > hotbarTop) {
        top = hotbarTop - widgetH * hudScale;
    }
    float gw = 6.0;
    float gh = 8.0;
    float yOff = 28.0;
    if (hudB == 5) {
        yOff = 9.0;
    } else if (hudB == 24) {
        gw = 24.0;
        gh = 24.0;
        yOff = 12.0;
    } else if (hudB >= 100) {
        gw = widgetW;
        gh = widgetH;
        yOff = 0.0;
    }
    int corner = gl_VertexID % 4;
    float lx = (corner == 2 || corner == 3) ? gw : 0.0;
    float ly = (corner == 1 || corner == 2) ? gh : 0.0;
    float px = left + (float(hudG) + lx) * hudScale;
    float py = top + (yOff + ly) * hudScale;
    // z=0 интерфейс вырезает. Глубину оставляем как у обычной надписи.
    vec4 hudAnchor = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vec4 hudMoved = ProjMat * vec4(px, py, 0.0, 1.0);
    gl_Position = vec4(hudMoved.x, hudMoved.y, hudAnchor.z, hudAnchor.w);
    hudTint = hudB >= 20 ? vec4(1.0) : vec4(1.0, 0.82, 0.28, 1.0);
    hudDone = true;
}
if (!hudDone) {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
}

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = hudDone ? hudTint : hudTint * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
