#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
vec4 hudTint = Color;
bool hudDone = false;
int hudR = int(Color.r * 255.0 + 0.5);
int hudG = int(Color.g * 255.0 + 0.5);
int hudB = int(Color.b * 255.0 + 0.5);
if (hudR == 56) {
    gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
    hudTint = vec4(0.0);
    hudDone = true;
} else if (hudR == 225 && (hudB == 5 || hudB == 6 || hudB == 30 || hudB == 168)) {
    float guiW = 2.0 / max(abs(ProjMat[0][0]), 0.0001);
    float guiH = 2.0 / max(abs(ProjMat[1][1]), 0.0001);
    float widgetW = 168.0;
    float widgetH = 46.0;
    float margin = 6.0;
    float hudScale = 1.0;
    if (widgetW + margin * 2.0 > guiW * 0.48) {
        hudScale = (guiW * 0.48 - margin * 2.0) / widgetW;
    }
    if (widgetH * hudScale > guiH * 0.28) {
        hudScale = min(hudScale, (guiH * 0.28) / widgetH);
    }
    hudScale = max(hudScale, 0.45);
    float left = guiW - margin - widgetW * hudScale;
    float top = guiH - margin - widgetH * hudScale;
    float hotbarRight = guiW * 0.5 + 96.0;
    if (left < hotbarRight) {
        top = guiH - 26.0 - widgetH * hudScale;
    }
    float gw = 6.0;
    float gh = 8.0;
    float yOff = 26.0;
    if (hudB == 5) {
        yOff = 8.0;
    } else if (hudB >= 100) {
        gw = 168.0;
        gh = 46.0;
        yOff = 0.0;
    } else if (hudB >= 20) {
        gw = 30.0;
        gh = 30.0;
        yOff = 8.0;
    }
    int corner = gl_VertexID % 4;
    float lx = (corner == 2 || corner == 3) ? gw : 0.0;
    float ly = (corner == 1 || corner == 2) ? gh : 0.0;
    gl_Position = ProjMat * vec4(left + (float(hudG) + lx) * hudScale, top + (yOff + ly) * hudScale, Position.z, 1.0);
    hudTint = hudB >= 20 ? vec4(1.0) : vec4(1.0, 0.82, 0.28, 1.0);
    hudDone = true;
}
if (!hudDone) {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
}

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = hudTint * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
